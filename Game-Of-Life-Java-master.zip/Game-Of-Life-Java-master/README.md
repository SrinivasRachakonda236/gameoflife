# Game-Of-Life-Java
A very simple console implementation of Conway's "game of life" on a fixed size matrix.
